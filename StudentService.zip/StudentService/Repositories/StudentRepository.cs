﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Gestion_BU.Entities;

namespace Gestion_BU.Repositories
{
    public class StudentRepository
    {
        private static List<Student> _students = new List<Student>()
        {
            new Student("quentin.martinez@outlook.com", 1)
            {
                NbEmpruntMaximum = 10,
                NbLivreEmprunte = 2,
            } ,

            new Student("john.wick@continental.com", 1)
            {
                NbEmpruntMaximum = 5,
                NbLivreEmprunte = 2,
            },
            new Student("harry.potter@continental.com", 1)
            {
                NbEmpruntMaximum = 5,
                NbLivreEmprunte = 0,
            }
        };


        public void Add(Student student)
        {
            _students.Add(student);
        }
        public bool Exists(string emailAddress)
        {
           return _students.Any(student => student.EmailAddress == emailAddress);
        }

        public List<Student> GetStudents()
        {
            return _students.ToList();
        }
    }
}
