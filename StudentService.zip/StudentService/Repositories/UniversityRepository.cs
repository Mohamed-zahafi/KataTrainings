﻿
using Gestion_BU.Entities;

namespace Gestion_BU.Repositories
{
    public class UniversityRepository
    {

        private List<University> Universities = new List<University>()
        {
             new University()
            {
                Id = 1,
                Name = "Cambrigde",
                Package = Package.Standard
            },
               new University()
            {
                Id = 1,
                Name = "Poudlard",
                Package = Package.Premium
            }
    };
        public University GetById(int universityId)
        {
            return Universities.Single(x => x.Id == universityId);
        }

        public List<University> GetAll()
        {
            return Universities.ToList();
        }

}
}
