﻿using Gestion_BU.Entities;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace Gestion_BU.ViewModels
{
    public class StudentViewModel
    {
        public StudentViewModel()
        {

        }
        public StudentViewModel(List<University> universities)
        {
            Universites = new SelectList(universities, "Id", "Nom");
        }
        public string Email { get; set; }
        public string UniversityId { get; set; }

        public SelectList Universites { get; set; }
    }
}
