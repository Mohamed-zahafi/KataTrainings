﻿namespace Gestion_BU.Entities
{
    public enum Package
    {
        Standard = 1,
        Premium = 2,
    }
}
