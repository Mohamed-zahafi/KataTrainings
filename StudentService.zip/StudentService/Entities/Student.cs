﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Gestion_BU.Entities
{
    public class Student
    {
        public string EmailAddress { get; private set; }
        public int UniversityId { get; private set; }
        public int NbEmpruntMaximum { get; set; }
        public int NbLivreEmprunte { get; set; }

        public Student(string emailAddress, int universityId)
        {
            EmailAddress = emailAddress;
            UniversityId = universityId;
        }
    }
}
