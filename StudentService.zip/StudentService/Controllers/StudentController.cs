﻿using Gestion_BU.Repositories;
using Gestion_BU.Services;
using Microsoft.AspNetCore.Mvc;

namespace Gestion_BU.Controllers
{
    public class StudentController : Controller
    {
        private readonly Services.StudentService _studentService;
        private readonly UniversityRepository _universityRepository;

        public StudentController(Services.StudentService studentService, UniversityRepository universityRepository)
        {
            _studentService = studentService;
            _universityRepository = universityRepository;
        }

        public IActionResult Index()
        {
            return View();
        }


        public IActionResult Add()
        {
            var vm = new ViewModels.StudentViewModel(_universityRepository.GetAll());
            return View(vm);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Add(ViewModels.StudentViewModel viewModel)
        {
            var vm = new ViewModels.StudentViewModel(_universityRepository.GetAll());
            return View(vm);
        }
    }
}
